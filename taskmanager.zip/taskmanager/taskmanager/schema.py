import graphene
from graphene_django.types import DjangoObjectType
from tasks.models import Task

class TaskType(DjangoObjectType):
    class Meta:
        model = Task
        fields = ("id", "title", "status", "created_at", "assigned_to")

class Query(graphene.ObjectType):
    all_tasks = graphene.List(TaskType)

    def resolve_all_tasks(self, info):
        user = info.context.user
        if user.is_anonymous:
            raise Exception("Authentication required!")
        return Task.objects.filter(assigned_to=user)

schema = graphene.Schema(query=Query)
