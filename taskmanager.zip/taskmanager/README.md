# Task Manager Backend

Django + DRF + GraphQL backend for managing personal tasks.

## Features
- Token authentication
- REST APIs: list/create/update/delete tasks
- GraphQL API: list tasks
- Each task tied to logged-in user

## Setup
```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
